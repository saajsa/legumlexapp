class LanguageModel {
  String languageFlag;
  String languageName;
  String languageCode;
  String countryCode;

  LanguageModel(
      {required this.languageFlag,
      required this.languageName,
      required this.countryCode,
      required this.languageCode});
}
