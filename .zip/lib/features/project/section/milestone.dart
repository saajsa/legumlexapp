import 'package:flutter/material.dart';

class MilestoneWidget extends StatelessWidget {
  const MilestoneWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [Center(child: Text('Comming Soon'))],
    );
  }
}
