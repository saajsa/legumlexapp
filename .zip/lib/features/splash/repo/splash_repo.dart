import 'package:flutex_customer/core/service/api_service.dart';

class SplashRepo {
  ApiClient apiClient;
  SplashRepo({required this.apiClient});
}
